I created this package mainly for personal use containing functions I frequently use when writing selenium python code. 
This package offers functionality to speed up selenium development in python with appropriate error handling.
- checking if elements exist
- waiting for elements to exist
- clicking
- right clicking
- simulating thinking
- scrolling